# Vibrante × Prism Pipeline Integration Pack

A complete set of **46 integration nodes** that turn Vibrante-Node into a fully-fledged Prism Pipeline front-end. Every major area of the Prism Python API (`PrismCore` and its sub-modules) is exposed as a JSON node definition that drops straight into Vibrante's `nodes/` folder.

Built against the public Prism Pipeline API: <https://prism-pipeline.com/docs/latest/development/apiExamples/>

---

## 📦 Installation

1. Copy every `prism_*.json` file in this pack into the Vibrante `nodes/` directory of your install:

   ```text
   <Vibrante-Node>/nodes/
   ```

2. (Optional) drop the `icons/` folder contents into `<Vibrante-Node>/icons/` if you want the suggested icons (any missing icon falls back to the default).

3. Restart Vibrante (or hit **Reload Nodes** in the library panel). All nodes will appear in the library under categories prefixed `Prism/...`.

4. Optionally, copy `example_workflow_prism_demo.json` into `<Vibrante-Node>/workflows/` and open it from **File → Open Workflow** to see a working end-to-end pipeline.

### Prism prerequisites
- A working install of **Prism Pipeline 2** (default `C:/Program Files/Prism2/Scripts`).
- Or run inside a DCC that already has Prism loaded (Houdini, Maya, Blender, Nuke, 3dsMax, Unreal, Substance Painter) — the `Prism: Init Core` node will reuse the existing `pcore` instance automatically.

---

## 🧱 Architecture

Every node follows Vibrante's `BaseNode` contract:

- **Flow pins** (`exec_in` / `exec_out`) so nodes chain in a deterministic order.
- **A `core` data port** that carries the `PrismCore` instance through the graph. You wire one `Prism: Init Core` node at the top of your workflow and feed its `core` output into every subsequent Prism node.
- **Data-only helper** (`Prism: Build Entity Dict`) is declared with `use_exec: false`, so it reactively rebuilds its `entity` dict whenever you change a widget — no execution pin needed.
- **Strict error capture**: every node wraps the underlying Prism call in `try/except`, logs through `self.log_error(…)`, and returns a `success` boolean output so downstream graphs can branch on failures.
- **Defensive method probing**: where Prism has renamed methods between versions (e.g. `getProductsFromEntity` vs `getProducts`), nodes try multiple known names so they keep working across releases.

---

## 📚 Node Index (46 nodes)

### 🔹 Core (3)
| Node | Wraps |
|---|---|
| `Prism: Init Core` | `PrismCore.create() / PrismCore.show()` — also reuses an existing in-DCC `pcore` |
| `Prism: Core Info` | `core.version`, `core.projectName`, `core.projectPath`, `core.username` |
| `Prism: Eval Python` | Escape hatch — runs an arbitrary Python snippet with `core` injected |

### 🔹 Projects (3)
| Node | Wraps |
|---|---|
| `Prism: Create Project` | `core.projects.createProject(name, path, preset)` |
| `Prism: Change Project` | `core.changeProject(path)` |
| `Prism: List Projects` | `core.projects.getProjects()` |

### 🔹 Entities (8)
| Node | Wraps |
|---|---|
| `Prism: Build Entity Dict` | Pure data helper that builds the `{type, asset_path}` / `{type, sequence, shot}` dict |
| `Prism: Create Entity` | `core.entities.createEntity(entity)` |
| `Prism: Get Assets` | `core.entities.getAssets()` |
| `Prism: Get Shots` | `core.entities.getShots()` → sequences, shots |
| `Prism: Get Departments` | `core.entities.getDepartments(entity)` |
| `Prism: Get Tasks` | `core.entities.getTasks(entity, department)` |
| `Prism: Create Category` | `core.entities.createCategory(entity, department, task)` |
| `Prism: Get Preset Scenes` | `core.entities.getPresetScenes()` (with extension filter) |

### 🔹 Scenes (5)
| Node | Wraps |
|---|---|
| `Prism: Create Scene From Preset` | `core.entities.createSceneFromPreset(entity, file, dept, task, comment=…)` |
| `Prism: Get Scene Files` | `core.entities.getScenefiles(entity, department=…, task=…)` |
| `Prism: Open Scene` | `core.openScene()` / `core.appPlugin.openScene()` |
| `Prism: Save Scene Version` | `core.saveScene()` / `core.saveSceneVersion()` |
| `Prism: Get Current Scene` | `core.getCurrentFileName()` + `core.getScenefileData()` |

### 🔹 Products (5)
| Node | Wraps |
|---|---|
| `Prism: Get Products` | `core.products.getProductsFromEntity(entity)` |
| `Prism: Get Product Versions` | `core.products.getVersionsFromProduct(product)` |
| `Prism: Get Latest Product Path` | `core.products.getLatestVersionFromProduct(name, entity)` |
| `Prism: Create Product Version` | `core.products.createProduct(entity, task, comment, …)` |
| `Prism: Import Product` | `core.products.importProduct(path)` / `core.appPlugin.importFile()` |

### 🔹 Media (4)
| Node | Wraps |
|---|---|
| `Prism: Get Media` | `core.mediaProducts.getMediaProductsFromEntity(entity)` |
| `Prism: Get Media Versions` | `core.mediaProducts.getVersionsFromIdentifier(media)` |
| `Prism: Get AOVs` | `core.mediaProducts.getAOVsFromVersion(version)` |
| `Prism: Create Playblast` | `core.mediaProducts.createPlayblast(...)` / `appPlugin.createPlayblast()` |

### 🔹 Plugins (3)
| Node | Wraps |
|---|---|
| `Prism: Get Plugin` | `core.plugins.getPlugin(name)` (alias `core.getPlugin`) |
| `Prism: List Plugins` | `core.plugins.getLoadedPlugins()` |
| `Prism: Monkey-Patch Function` | `core.plugins.monkeyPatch(target, replacement, owner, force=True)` |

### 🔹 Callbacks (2) — bridges Prism events into Vibrante flow graphs
| Node | Wraps |
|---|---|
| `Prism: Register Callback` | `core.callbacks.registerCallback(name, fn)` — emits the `triggered` exec pin **inside Vibrante** every time the Prism event fires (e.g. `onShotCreated`, `onSceneSaved`, `onProductCreated`). |
| `Prism: Trigger Callback` | `core.callbacks.callback(name, *args)` — manually fire a callback |

### 🔹 Configs (3)
| Node | Wraps |
|---|---|
| `Prism: Get Config` | `core.getConfig(category, key, config=…)` |
| `Prism: Set Config` | `core.setConfig(category, key, value, config=…)` |
| `Prism: Get Project Config Path` | `core.configs.getProjectConfigPath(projectPath)` |

### 🔹 USD Plugin (5)
| Node | Wraps |
|---|---|
| `Prism USD: New Entity Path` | `plugin.api.getNewEntityUsdPath(entity=…)` |
| `Prism USD: New Department Layer Path` | `plugin.api.getNewDepartmentLayerPath(entity, department)` |
| `Prism USD: New Sublayer Path` | `plugin.api.getNewSublayerPath(entity, department, sublayer)` |
| `Prism USD: Update Department Layer` | `plugin.api.updateDepartmentLayerInCurrentEntityUSD(path)` |
| `Prism USD: Update Sublayer in Department` | `plugin.api.updateLayerInDepartmentLayer(path)` |

### 🔹 DCC Comms (1)
| Node | Wraps |
|---|---|
| `Prism: Send Cmd to DCC` | `getPlugin('PrismInternals').internals.sendCmd(target_dcc, code)` |

### 🔹 Auth, Setup, Studio, Utility (4)
| Node | Wraps |
|---|---|
| `Prism: Login (Access Token)` | `getPlugin('PrismInternals').internals.login(accessToken=…)` |
| `Prism: Add DCC Integration` | `core.integration.addIntegration(dcc, path)` / `addAllIntegrations()` |
| `Prism Studio: Assign User to Project` | `getPlugin('Studio').setProjectsAssignedToUsers(...)` |
| `Prism: Popup` | `core.popup(message, title=…)` |

---

## 🚀 Example workflow (`example_workflow_prism_demo.json`)

A ready-to-load Vibrante workflow showing a real chain:

```text
[Init Core] → [Create Project] → [Change Project] → [Create Entity] → [Create Category]
       │                                                      ▲
       │                              [Build Entity Dict] ────┘
       │
       └──→ [Get Preset Scenes] → [Create Scene From Preset] → [Popup]
```

The `core` output of `Init Core` is fanned out to every node that needs Prism, while the `entity` output of `Build Entity Dict` is fed into every node that needs an entity. This is the canonical pattern for any Prism workflow.

---

## 🧠 Tips

- **Single source of truth for `core`.** Use one `Prism: Init Core` per workflow and pass its `core` output into every other Prism node — don't create multiple cores.
- **Reuse `Prism: Build Entity Dict`.** Because it's a data-only node (`use_exec: false`), it updates reactively and can feed many downstream nodes in parallel.
- **Use `Prism: Eval Python` as an escape hatch.** Anything missing from this pack (or a method new in a future Prism release) can be called directly: assign your result to a variable named `result`.
- **Branch on `success`.** Every action node returns a `success` bool. Wire it into a **Branch** node from the standard Vibrante library to take corrective action on failure.
- **Bridge Prism events into Vibrante.** Drop a `Prism: Register Callback` node into your graph, choose a callback (e.g. `onShotCreated`), and connect its `triggered` exec output to whatever you want to run when Prism fires that event — e.g. send a Slack message, write a log row, kick off a render submission.
- **Cross-DCC automation.** Use `Prism: Send Cmd to DCC` to push Python into a running Houdini/Maya/Blender from a Vibrante graph.

---

## 📄 License

Released under the same terms as Vibrante-Node — free for personal and non-commercial use. Commercial / redistribution requires written permission from the author.
